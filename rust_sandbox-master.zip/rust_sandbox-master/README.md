# Rust Sandbox

> Some fundamental syntax of the Rust language. This is from the Traversy Media "Rust Crash Course" on YouTube

## Quick Start
Un-comment the file function to run

``` bash
# Run With Cargo
cargo run

# Build
cargo build

# Build for production
cargo build --release
```
